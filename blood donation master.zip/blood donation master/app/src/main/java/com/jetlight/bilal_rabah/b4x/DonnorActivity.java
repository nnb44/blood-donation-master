package com.jetlight.bilal_rabah.b4x;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class DonnorActivity extends AppCompatActivity {

    ListView list;
    Button btnRequest;
    String[] maintitle ={
            "بلال ","احمد ",
            "ماهر ","حسين",
            "حسن ",
            "احمد ","زهراء ",
            "مآبي ","زينب",
            "كريم ",
            " كرار","اسامه ",
            "الطيب ","ايمن ",
            "سلام ",
            "مينا ","زهراء ",
            "الامين ","سطام",
            "عبد الرحمن",
    };

    String[] subtitle ={
            "2 كم","5 كم",
            "4 كم","7 كم",
            "8 كم",
            "2 كم","5 كم",
            "4 كم","7 كم",
            "8 كم",
            "2 كم","5 كم",
            "4 كم","7 كم",
            "8 كم",
            "2 كم","5 كم",
            "4 كم","7 كم",
            "8 كم",
    };

    Integer[] imgid={
            R.mipmap.avatar1,R.mipmap.avatar2,
            R.mipmap.avatar3,R.mipmap.avatar1,
            R.mipmap.avatar2,
            R.mipmap.avatar1,R.mipmap.avatar2,
            R.mipmap.avatar3,R.mipmap.avatar1,
            R.mipmap.avatar2,
            R.mipmap.avatar1,R.mipmap.avatar2,
            R.mipmap.avatar3,R.mipmap.avatar1,
            R.mipmap.avatar2,
            R.mipmap.avatar1,R.mipmap.avatar2,
            R.mipmap.avatar3,R.mipmap.avatar1,
            R.mipmap.avatar2,
    };

    public void CallHim(View view)
    {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:07801111111"));
        startActivity(intent);
    }
    public void ViewProfile(View view)
    {
        Intent intent = new Intent(this,ProfileActivity.class);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donnor);
        MyListAdapter adapter=new MyListAdapter(this, maintitle, subtitle,imgid);
        list=(ListView)findViewById(R.id.list);
        btnRequest= (Button) findViewById(R.id.btnRequest);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    Toast.makeText(getApplicationContext(),"الخيار الاول",Toast.LENGTH_SHORT).show();
                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Toast.makeText(getApplicationContext(),"الخيار الثاني",Toast.LENGTH_SHORT).show();
                }

                else if(position == 2) {

                    Toast.makeText(getApplicationContext(),"الخيار الثالث",Toast.LENGTH_SHORT).show();
                }
                else if(position == 3) {

                    Toast.makeText(getApplicationContext(),"الخيار الرابع",Toast.LENGTH_SHORT).show();
                }
                else if(position == 4) {

                    Toast.makeText(getApplicationContext(),"الخيار الخامس",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void GoSearch(View view) {
        Intent intent = new Intent(this,SearchActivity.class);
        startActivity(intent);
    }

    public void Request(View view) {
        if( btnRequest.getText().equals("اطلب دم")) {
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which) {
                        case DialogInterface.BUTTON_POSITIVE:
                            //Yes button clicked

                            Toast.makeText(DonnorActivity.this, "لقد طلبت دم فئة AB",
                                    Toast.LENGTH_LONG).show();
                            btnRequest.setText("حالة الطلب");
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            //No button clicked
                            break;
                    }
                }

            };

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("هل انت متآكد ").setPositiveButton("نعم", dialogClickListener)
                    .setNegativeButton("لا", dialogClickListener).show();
        }
        else {
            Intent intent = new Intent(this,StatusActivity.class);
            startActivity(intent);
        }
    }
    public void MyProfile(View view)
    {
        Intent intent = new Intent(this,AccountActivity.class);
        startActivity(intent);
    }
}
